package com.ciencialoca.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiencialocaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
