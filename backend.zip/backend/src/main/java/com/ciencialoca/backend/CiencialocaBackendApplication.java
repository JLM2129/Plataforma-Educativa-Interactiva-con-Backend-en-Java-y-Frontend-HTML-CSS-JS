package com.ciencialoca.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiencialocaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiencialocaBackendApplication.class, args);
	}

}
